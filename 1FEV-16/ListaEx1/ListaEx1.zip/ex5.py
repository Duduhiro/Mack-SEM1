fruta = input("Insira o nome de uma fruta: ")
verdura = input("Insira o nome de uma verdura: ")
legume = input("Insira o nome de um legume: ")
print("Aqui estão os nomes de uma fruta, verdura e legume: \n"
      , fruta, "\n"
      , verdura, "\n"
      , legume,)