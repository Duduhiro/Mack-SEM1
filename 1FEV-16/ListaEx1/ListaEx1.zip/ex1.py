print("Esse programa calcula a média de 3 notas diferentes")
nota1 = float(input("Insira a primeira nota: "))
nota2 = float(input("Insira a segunda nota: "))
nota3 = float(input("Insira a terceira nota: "))
avg = (nota1 + nota2 + nota3) / 3
print("A média dessas 3 notas é igual a: %.1f" %(avg))