n1 = int(input("Insira um número para ser salvo na variável N1: "))
n2 = int(input("Insira outro número para ser salvo na variável N2: "))

troca = n1
n1 = n2
n2 = troca

print(f"Como as variáveis foram invertidas, N1 vale {n1} e N2 vale {n2}")