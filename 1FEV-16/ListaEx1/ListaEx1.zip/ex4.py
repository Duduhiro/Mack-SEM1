print("Ola, mundão!") # Ola, mundão!

print("Ola", "mundao") # Ola mundao

print(3) # 3

print(3.0) # 3.0

print(2 + 3) # 5

print(2.0 + 3.0) # 5.0

print("2" + "3") # 23

print("1 + 3 =", 2 + 3) # 1 + 3 = 5

print(2 * 3) # 6

print(2 ** 3) # 8

print(2 / 3)

print("---------------break---------------")

type(3) # nada

type("Tipo inteiro?") # nada

type("Tipo String") # nada

type(3.0) # nada

type(4/2) # nada

type("3") # nada

type("4/2") # nada

type("3.0") # nada
