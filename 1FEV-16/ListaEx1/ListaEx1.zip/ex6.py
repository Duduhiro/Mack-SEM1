fruta = input("Insira o nome de uma fruta: ")
priceFruit = float(input("Insira o preço dessa fruta: "))
verdura = input("Insira o nome de uma verdura: ")
priceVerdura = float(input("Insira o preço dessa verdura: "))
legume = input("Insira o nome de um legume: ")
priceLegume = float(input("Insira o preço desse legume: "))

print("Aqui está a sua lista de alimentos: \n%s %.2f\n%s %.2f\n%s %.2f" %(fruta, priceFruit, verdura, priceVerdura, legume, priceLegume))
