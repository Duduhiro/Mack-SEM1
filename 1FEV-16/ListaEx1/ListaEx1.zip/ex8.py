text = input("Insira um texto: ")
num = input("Insira um número")
print("A primeira entrada é um dado do tipo String")
print("A segunda entrada é um dado do tipo int")